package com.virtusa.services;

public interface jobServices {

	public void viewjobPosts();

	public void addJobPost();


	
	
}
