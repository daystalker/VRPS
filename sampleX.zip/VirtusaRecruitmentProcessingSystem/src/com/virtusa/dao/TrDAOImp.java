 package com.virtusa.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import com.virtusa.integrate.ConnectionManager;
import com.virtusa.model.JobseekerModel;
import com.virtusa.view.TRView;

public class TrDAOImp 
{

	/*public List<JobseekerModel> getAllJobSeekers(){
		
		/*private String fname;
	private String mname;
	private String lname;
	private Date datex;
	private int passYear;
	private int experience;
	private String address;
	private String qualification;
	private String email;
	private String phone;
	private float percentage;
	private String uname;
	private String password;
	private List<String> skills;
	
		
		try(Connection connection=ConnectionManager.openConnection();){
			String st="select REFERENCE_ID,JOBSEEKER_ID from application_and_status where ADMIN_STATUS='yes'";
			PreparedStatement ps=connection.prepareStatement(st);				
			ResultSet rs=ps.executeQuery();
			List<JobseekerModel> data=new ArrayList<>();
			if(rs.next()==false) {
				System.out.println(" Sorry,there are no Applications shorlisted by Admin\n Contact Admin or Please wait for further Instructions");
			}else
			{
				
			}
			
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
	}
*/
		public void  TrShortlist()
		{
			try(Connection connection=ConnectionManager.openConnection();){
				//String query1="select REFERENCE_ID,JOBSEEKER_ID from applications";
				
				String stat="";
				String st="select REFERENCE_ID,JOBSEEKER_ID from application_and_status where ADMIN_STATUS='yes'";
				PreparedStatement ps=connection.prepareStatement(st);				
				ResultSet rs=ps.executeQuery();
				
				if(rs.next()==false) {
					System.out.println(" Sorry,there are no Applications shorlisted by Admin\n Contact Admin or Please wait for further Instructions");
				}
				else {
					System.out.println("%%% Use LowerCase style while Operating %%%\n");
				System.out.println("\n|REFERENCE_ID|JOBSEEKER_ID|" );
				
				while(rs.next()) {
					System.out.println("|"+rs.getInt("REFERENCE_ID")+"|"+rs.getInt("JOBSEEKER_ID")+"|");
					System.out.println("<-Select this Candidate(Yes/No)->:");
					try(Scanner s=new Scanner(System.in);){
						 stat=s.next();
					}
					String set="update application_and_status set TR_STATUS=? where REFERENCE_ID=?";
					PreparedStatement ps1=connection.prepareStatement(set);
					ps1.setString(1,stat);
					ps1.setInt(2, rs.getInt("REFERENCE_ID"));
					int q=ps1.executeUpdate();
					if(q>0)
						System.out.println(" ---TR Status succesfully updated for Applicant:"+rs.getInt("REFERENCE_ID")+"----");
					else
						System.out.println("***TR Status updation failed:***");		
								}
				   }
			}
			catch(Exception e) {}
				
	}		
public void rate_comment() {
			// TODO Auto-generated method stub
			String comment;
			int rating;
			
			try(Scanner scan =new Scanner(System.in);){
			
			try(Connection connection=ConnectionManager.openConnection();)
			{
				/*String query1="select REFERENCE_ID,JOBSEEKER_ID from applications";
				 * 
				 *This is a generic query 
				 * String st="select REFERENCE_ID,JOBSEEKER_ID from application_and_status where ADMIN_STATUS='yes' ";
				 * retrieves data that we need accordingly in this scope of functionality
				*/
				String st="select reference_id,jobseeker_id from application_and_status where ADMIN_STATUS='yes' ";
				PreparedStatement rate=connection.prepareStatement(st);
				ResultSet rps=rate.executeQuery();
				
				
				while(rps.next()) {
					
					System.out.println("___________________________");
					System.out.println("|REFERENCE_ID|JOBSEEKER_ID|");
					System.out.println("___________________________");
					
					System.out.println(rps.getInt("reference_id")+"\t|"+rps.getInt("jobseeker_id")+"\n");///////////////////////////
					
					
					System.out.println("Enter Rating ( out of 5 ) for this candidate:");
					rating=scan.nextInt();
					System.out.println("Enter Comments on this candidate:");
					comment=scan.next();
					
					
					String setter="update table RATING_COMMENT set TR_RATING=?,TR_RATING=? where JOBSEEKER_ID=?";
					PreparedStatement rate1=connection.prepareStatement(setter);
					rate1.setInt(3, rps.getInt("JOBSEEKER_ID"));
					rate1.setInt(1, rating);
					rate1.setString(2, comment);
					
					int r=rate1.executeUpdate();
					
					if(r>0) {
						System.out.println("Rating and Comment Successfully given by TR");
						
					}
					else {
						System.out.println("Problem at giving Rating and Comment by TR");
						
					}
				}
				
				TRView backing=new TRView();
				backing.mainMenu();
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error at TR's Rating and Commenting Service");
															}
		}
	}		
}
