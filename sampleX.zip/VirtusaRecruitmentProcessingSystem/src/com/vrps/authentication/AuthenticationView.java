package com.vrps.authentication;

import java.util.Scanner;

import com.virtusa.model.LoginModel;
import com.virtusa.model.SessionForwading;


public class AuthenticationView {

//public static void main(String[] args) {
	
	// try putting Login model for username,password and then retrieving data from it
		public SessionForwading main(int option) {
		// TODO Auto-generated method stub

		Scanner scanner1=new Scanner(System.in);
		System.out.print("Enter UserName:");
		String username=scanner1.next();
		System.out.print("Enter Password:");

		String password=scanner1.next();
	
		LoginModel lm=new LoginModel(username,password);
		String password1=scanner1.next();

		UserAuthentication auth=new UserAuthentication();
		// boolean result;
		 SessionForwading sf =auth.Verification(lm,option );
		 scanner1.close();
		// System.out.print("----result--"+sf.isStatus());
		 return sf;
	}

}

